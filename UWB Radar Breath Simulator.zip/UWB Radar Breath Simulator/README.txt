
%% AUTHOR: Cansu EREN 
%% @ Copyright Cansu EREN 
%% 18/10/2023

%% File List 
%% AnteriorPosterior: The simulated data is obtained regarding the anterior-posterior position of human towards radar. 
%% MedioLateral: The simulated data is obtained regarding the anterior-posterior position of human towards radar. 
%% Simulated Data Library: The data file location of simulated breath signals on MATLAB. 

%% Additional Documents 
%% GNU General Public License v3.0: The license type of this code is given in this file. 
%% ODC Open Database License(ODbL): The license type of this data is given in this file. 

%% THANKS FOR READING! 





