function [GaussPulse] = GaussPulseGenerator(Pulsewidth,MaskdB, tlocal)

%GaussPulseGenerator generates Gauss pulses. 

% INPUTS 
% MaskdB= Power level of pulse, dB. 
% Pulsewidth= Signal pulse duration, seconds. 
% tlocal= time vector for a pulse, seconds. 

% Generation of Gauss pulse. 

FCCMaskPower=10^( (MaskdB)/10);   % conversion of dB to watt
GaussPulse=exp(-4*pi.*(tlocal/Pulsewidth).^2);  % generation of Gaussian signal.
GaussPulse=GaussPulse/max(GaussPulse); % normalization 
GaussPulse=sqrt(2)*sqrt(FCCMaskPower*50).*GaussPulse; % amplitude multiplication. 

% Outputs
% GaussPulse: Generated Gauss pulse, seconds.  

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 
