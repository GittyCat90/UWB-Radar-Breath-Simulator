function [Coefficient] =...
    SingleBreathCoefficientCalculation(Tissue, PathLoss, PeriodNumber)

%SingleBreathCoefficientCalculation of this function is given below.

% Create variable name arrays for calling the total reflections in "Tissue"
% data. 

ConstantTotalReflectionInflated="Tissue.TotalReflection.Inflated.R"; 
ConstantTotalReflectionDeflated="Tissue.TotalReflection.Deflated.R"; 
TotalRefLayer=["2" "3" "4" "5" "6" "7" "8" "9" "10" "11" "12" ];

% Create a random teta array generator between NumberofSamplesSingleCycleMin and 
% NumberofSamplesSingleCycleMax. 

NumberofSamplesSingleCycleMax= 100; 
NumberofSamplesSingleCycleMin=80; 

 SampleNumbers =...
     randi([NumberofSamplesSingleCycleMin,NumberofSamplesSingleCycleMax],PeriodNumber,1); 
 
 % Calculate the reflection coefficients and path losses between the deflated and inflated
 % lung positions, considering the sinusoidal movement of the lung.  
                
                for jj=1:length(SampleNumbers) 
                    
                    Teta=linspace(0, 180, SampleNumbers(jj)); 
                
                                    for kk=1:length(Teta) 
                                
                                            for ii=1:length(TotalRefLayer) 
                                
                                                        VarNameTotalReflectionInflated=...
                                                            eval(strcat(ConstantTotalReflectionInflated, TotalRefLayer(ii))); 
                                                        VarNameTotalReflectionDeflated=...
                                                            eval(strcat(ConstantTotalReflectionDeflated, TotalRefLayer(ii))); 
                                    
                                                        Gamma(:,ii,kk)=...
                                                            VarNameTotalReflectionDeflated+...
                                                            sind(Teta(kk)).*(VarNameTotalReflectionInflated-VarNameTotalReflectionDeflated); 
                                                        Loss(:,ii,kk)=...
                                                            PathLoss.LungDeflated(:,ii)+...
                                                            sind(Teta(kk))*(PathLoss.LungInflated(:,ii)- PathLoss.LungDeflated(:,ii)); 
                                
                                            end 
                                            
                                    end 
                        
                        GammaCell{jj}=Gamma; 
                        LossCell{jj}=Loss; 
                        Gamma=[]; 
                        Loss=[]; 
                
                end 

% OUTPUTS 
% GammaCell: The total reflection coefficients considering the frequency, tissue
% layers. The cell size is determined by period,  TotalRefLayer and SampleNumbers. 
% LossCell: The total path loss values considering the frequency and tissue
% layers, dB. The cell size is determined by period,  TotalRefLayer and
% SampleNumbers.  
% Sample Numbers: The total number of sample numbers for a given period
% number. 

Coefficient.GammaCell=GammaCell; 
Coefficient.LossCell=LossCell; 
Coefficient.SampleNumbers=SampleNumbers; 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 


