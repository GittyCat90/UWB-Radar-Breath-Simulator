clc
clear all 
close all 

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 

%% Step I-Select AP data and load AP tissue parameters%%
QuestionStruct.Interpreter='tex'; 
QuestionStruct.Default='Yes'; 
Question=...
    questdlg('\fontsize{14}\color{magenta}Select "UWB Breath Radar Simulator" file location', 'Question', 'Yes', 'No', 'Cancel', QuestionStruct); 

switch Question 
    case 'Yes'
      FilePath=uigetdir; 
    case 'No'
        MessageStruct.Interpreter='tex'; 
        MessageStruct.WindowsStyle='modal'; 
        Message=msgbox({'\fontsize{14}\color{magenta}You should select "UWB Breath Radar Simulator" file location'}, 'ReadMe', 'help', MessageStruct); 
        clc 
        clear all 
        close all 
       return 
    case 'Cancel'
        clc 
        clear all 
        close all 
        return 
end 

APFilePath=fullfile(FilePath, "AnteriorPosterior"); 
SimulatedFilePath=fullfile(FilePath, "Simulated Data Library"); 

cd(APFilePath)
APTissueDataPath=fullfile(APFilePath, "TissueProperties_AnteriorPosterior"); 
load(strcat(APTissueDataPath, "\", "TissueAnteriorPosterior.mat"));  

%% Step II-Define general parameters%% 

SpeedofLight=3e8;  %speed of light at vacumm, m/s.  
SamplingFrequency=120e9; % clock frequency, Hz. 
tsampling=1/SamplingFrequency;  % time resolution, seconds; 
CenterFrequency=Tissue.CenterFreq; %Hz 
RadarDistance=0.7; % m 
Pulsewidth=0.01e-9;  % seconds 
tlocal=-1e-9:tsampling:1e-9; % time vector, seconds. 
MaskdBm=-50;   % power mask, dBm. 
MaskdB=MaskdBm-30; % dbm to dB.  
PeriodNumber=[6 7 9 10 11 12 13 14 16 ];  % Array of breath periods. 
TimeDur=50;     %seconds

%% Step III-Simulate AP breath signals and save the simulated signals %% 

for ii=1:length(PeriodNumber) 

% Path loss calculation. 
 PathLoss = PathLossCalculation(CenterFrequency, RadarDistance, Tissue); 

% Time of Flight Calculation 
TotalDelay = ...
    TimeofFlightCalculation(RadarDistance,SpeedofLight,CenterFrequency, Tissue); 

% Single Breath Coefficient Calculation
 Coefficient = SingleBreathCoefficientCalculation(Tissue, PathLoss,PeriodNumber(ii));

  % Received Signals 
 ReceivedBreath =...
    ReceivedSignals(PeriodNumber(ii), Coefficient,MaskdB,Pulsewidth, tlocal); 

Length=length(squeeze(ReceivedBreath(1,1,:))) ; 
tt= 0: TimeDur/Length: TimeDur-TimeDur/Length; 

save(  strcat(SimulatedFilePath, "\AP_", "ReceivedBreath", num2str(PeriodNumber(ii)), ".mat"), "ReceivedBreath")
save( strcat(SimulatedFilePath, "\AP_",  "PathLoss", num2str(PeriodNumber(ii)), ".mat"), "PathLoss")

end 




 
 


