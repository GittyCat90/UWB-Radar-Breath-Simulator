function [TissueImpedance] = Impedance(CharImpedanceFreeSpace,TissueComplexPermittivity)
% Impedance calculates the characteristic impedance of human tissues. 

% INPUTS 
% CharImpedanceFreeSpace: Characteristic impedance of the free space, ohms.
% TissueComplexPermittivity: Relative permittivity of tissue, Farad/meter. 

TissueImpedance= abs ( CharImpedanceFreeSpace./sqrt(TissueComplexPermittivity) ); 

% OUTPUTS 
% TissueImpedance: Characteristic impedance of the material, ohms. 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 
