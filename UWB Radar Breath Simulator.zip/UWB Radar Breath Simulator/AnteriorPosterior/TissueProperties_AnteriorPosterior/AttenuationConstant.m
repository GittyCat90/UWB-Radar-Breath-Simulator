function [Alpha] = AttenuationConstant...
    (w, PermeabilityFreeSpace,PermittivityFreeSpace, TissuePermittivity,SkinConductivity)

% AttenuationConstant calculates the attenuation constant of electromagnetic wave
% regarding below constant values.  

% INPUTS
% PermeabilityFreeSpace: The permeability of free space, Newtons/
% (Ampere)^2. 
% PermittivityFreeSpace: The permittivity of free space, Farad/meter. 
% TissuePermittivity: The relative permittivity, Farad/meter. 
% SkinConductivity: The conductivity of material, S/m. 
% w: Wave pulsation. 

Param1=  (PermeabilityFreeSpace*PermittivityFreeSpace.*TissuePermittivity)/2;
Param2=sqrt ( 1+ (SkinConductivity./ (w.*PermittivityFreeSpace.*TissuePermittivity)).^2 )-1; 
Alpha= w.*sqrt (Param1.*Param2); 

% OUTPUTS 
% Alpha: Attenuation constant, Neper/m.

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 
