function [Velocity] = VelocityCalculation(ComplexPermittivity)

% VelocityCalculation calculates the velocity of an electromagnetic wave in
% a medium. 

%INPUTS 
% SpeedofLight= SpeedofLight in vacuum, m/s. 
% ComplexPermittivity=Complex dielectric presentation of the tissues,
% Farad/meter. 

SpeedofLight=3e8; 
Velocity=SpeedofLight./sqrt(ComplexPermittivity); 

% OUTPUTS 
% Velocity=The velocity of the electromagnetic wave in a tissue, m/s. 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 
