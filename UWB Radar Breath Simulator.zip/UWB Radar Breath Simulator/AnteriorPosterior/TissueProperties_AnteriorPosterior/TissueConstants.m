clc
clear all
close all
%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 

%% STEP 1: Select the main file location%% 

QuestionStruct.Interpreter='tex'; 
QuestionStruct.Default='Yes'; 
Question=...
    questdlg('\fontsize{14}\color{magenta}Select "UWB Breath Radar Simulator" file location', 'Question', 'Yes', 'No', 'Cancel', QuestionStruct); 

switch Question 
    case 'Yes'
      FilePath=uigetdir; 
    case 'No'
        MessageStruct.Interpreter='tex'; 
        MessageStruct.WindowsStyle='modal'; 
        Message=msgbox({'\fontsize{14}\color{magenta}You should select "UWB Breath Radar Simulator" file location'}, 'ReadMe', 'help', MessageStruct); 
        clc 
        clear all 
        close all 
       return 
    case 'Cancel'
        clc 
        clear all 
        close all 
        return 
end 

TissueFilePath=fullfile(FilePath, "AnteriorPosterior", "TissueProperties_AnteriorPosterior"); 

%%  STEP 2: Define radar center frequencies, real/imaginary/complex dielectric permittivity(Farad/meter), conductivity(S/m) of AP tissues%% 

Tissue.CenterFreq=[5.4e9 7.3e9 8e9]; %Hz 

% Real Permittivity(epsilon'), Farad/meter

Tissue.RealPermittivity.Skin= [34.49 32.31 31.43]; 
Tissue.RealPermittivity.BreastFat=  [4.873 4.62 4.523]; 
Tissue.RealPermittivity.Muscle=  [49.7 46.03 44.59]; 
Tissue.RealPermittivity.Cartilage=  [32.44 29.36 28.12]; 
Tissue.RealPermittivity.Heart=  [50.07 46.36 44.81]; 
Tissue.RealPermittivity.LungInflated=  [18.39 17.09 16.43]; 
Tissue.RealPermittivity.LungDeflated=  [43.37 40.1 38.83]; 
Tissue.RealPermittivity.Bone=[10.358 9.55 9.251]; 
Tissue.RealPermittivity.Fat=[4.3 4.14 4.071]; 
Tissue.RealPermittivity.Air=1.0006; 
Tissue.RealPermittivity.FreeSpace= 8.854e-12; 

%Imaginary Permittivity(epsilon''), Farad/meter 

Tissue.ImagPermittivity.Skin=[11.1 12.44 12.86]; 
Tissue.ImagPermittivity.BreastFat= [1.144 1.301 1.33]; 
Tissue.ImagPermittivity.Muscle=  [18.66 20.37 20.98]; 
Tissue.ImagPermittivity.Cartilage=  [13.03 13.7 13.81]; 
Tissue.ImagPermittivity.Heart= [18.83 21.18 22.02]; 
Tissue.ImagPermittivity.LungInflated= [6.365 7.189 7.437]; 
Tissue.ImagPermittivity.LungDeflated=  [15.83 17.43 17.9]; 
Tissue.ImagPermittivity.Bone=[3.4569 3.8223 3.909]; 
Tissue.ImagPermittivity.Fat= [0.785 0.9497 0.9760]; 

% Complex Dielectric Permittivity(epsilon), Farad/meter; 

Tissue.ComplexPermittivity.Skin= abs(Tissue.RealPermittivity.Skin-j.*Tissue.ImagPermittivity.Skin);
Tissue.ComplexPermittivity.BreastFat= abs(Tissue.RealPermittivity.BreastFat-...
                                                                j.*Tissue.ImagPermittivity.BreastFat); 
Tissue.ComplexPermittivity.Muscle=  abs(Tissue.RealPermittivity.Muscle-...
                                                                j.*Tissue.ImagPermittivity.Muscle); 
Tissue.ComplexPermittivity.Cartilage= abs(Tissue.RealPermittivity.Cartilage-...
                                                               j.*Tissue.ImagPermittivity.Cartilage); 
Tissue.ComplexPermittivity.Heart=...
    abs(Tissue.RealPermittivity.Heart-j.*Tissue.ImagPermittivity.Heart); 
Tissue.ComplexPermittivity.LungInflated= abs(Tissue.RealPermittivity.LungInflated...
                                                                    -j.*Tissue.ImagPermittivity.LungInflated);
Tissue.ComplexPermittivity.LungDeflated= abs(Tissue.RealPermittivity.LungDeflated-...
                                                                        j.*Tissue.ImagPermittivity.LungDeflated); 
Tissue.ComplexPermittivity.Bone=...
    abs(Tissue.RealPermittivity.Bone-j.*Tissue.ImagPermittivity.Bone); 
Tissue.ComplexPermittivity.Fat=abs(Tissue.RealPermittivity.Fat-...
                                                                j.*Tissue.ImagPermittivity.Fat); 

% Conductivity(sigma),  S/m

Tissue.Conductivity.Skin=[3.33 5.06 5.78]; 
Tissue.Conductivity.BreastFat= [0.3427 0.5277 0.598]; 
Tissue.Conductivity.Muscle= [ 5.605 8.276 9.429]; 
Tissue.Conductivity.Cartilage=[ 3.92 5.57 6.21]; 
Tissue.Conductivity.Heart= [5.658 8.608 9.895]; 
Tissue.Conductivity.LungInflated= [1.912 2.922 3.359]; 
Tissue.Conductivity.LungDeflated=  [4.753 7.083 8.057]; 
Tissue.Conductivity.Bone= [ 1.0384 1.5526 1.7569]; 
Tissue.Conductivity.Fat= [0.2358 0.3859 0.4387]; 

%%  STEP 3: Calculate velocity(m/s), characteristic impedances(ohms), reflection coeffients, propogation(rad/meter)/attenuation constants(Neper/meter) and skin depth (meters)%% 

% Velocity (m/s) 

Tissue.Velocity.Skin= VelocityCalculation(Tissue.ComplexPermittivity.Skin); 
Tissue.Velocity.BreastFat= VelocityCalculation(Tissue.ComplexPermittivity.BreastFat); 
Tissue.Velocity.Muscle= VelocityCalculation(Tissue.ComplexPermittivity.Muscle);
Tissue.Velocity.Cartilage= VelocityCalculation(Tissue.ComplexPermittivity.Cartilage);
Tissue.Velocity.Heart= VelocityCalculation(Tissue.ComplexPermittivity.Heart);
Tissue.Velocity.LungInflated= VelocityCalculation(Tissue.ComplexPermittivity.LungInflated);
Tissue.Velocity.LungDeflated= VelocityCalculation(Tissue.ComplexPermittivity.LungDeflated);
Tissue.Velocity.Bone= VelocityCalculation(Tissue.ComplexPermittivity.Bone);
Tissue.Velocity.Fat= VelocityCalculation(Tissue.ComplexPermittivity.Fat);

% Characteristic Impedance (Z), ohms

Tissue.Impedance.FreeSpace= 377;    
Tissue.Impedance.Skin = Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.Skin); 
Tissue.Impedance.BreastFat = ...
    Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.BreastFat); 
Tissue.Impedance.Muscle =...
    Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.Muscle); 
Tissue.Impedance.Cartilage = ...
    Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.Cartilage); 
Tissue.Impedance.Heart =...
    Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.Heart);  
Tissue.Impedance.LungInflated =...
    Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.LungInflated);  
Tissue.Impedance.LungDeflated = ...
    Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.LungDeflated); 
Tissue.Impedance.Bone = ...
    Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.Bone); 
Tissue.Impedance.Fat = Impedance(Tissue.Impedance.FreeSpace,Tissue.ComplexPermittivity.Fat); 

% Reflection Coefficient (ro)

Tissue.RefCoeff.AirSkin = ...
    ReflectionCoefficient(Tissue.Impedance.FreeSpace,Tissue.Impedance.Skin); 
Tissue.RefCoeff.SkinBreastFat=...
    ReflectionCoefficient(Tissue.Impedance.Skin ,Tissue.Impedance.BreastFat); 
Tissue.RefCoeff.BreastFatMuscle= ...
    ReflectionCoefficient(Tissue.Impedance.BreastFat ,Tissue.Impedance.Muscle); 
Tissue.RefCoeff.MuscleCartilage=...
    ReflectionCoefficient(Tissue.Impedance.Muscle ,Tissue.Impedance.Cartilage); 
Tissue.RefCoeff.CartilageFat=...
    ReflectionCoefficient(Tissue.Impedance.Cartilage,Tissue.Impedance.Fat); 
Tissue.RefCoeff.FatHeart= ReflectionCoefficient(Tissue.Impedance.Fat,Tissue.Impedance.Heart);
Tissue.RefCoeff.HeartLungInflated=...
    ReflectionCoefficient(Tissue.Impedance.Heart,Tissue.Impedance.LungInflated);
Tissue.RefCoeff.LungInflatedBone= ...
    ReflectionCoefficient(Tissue.Impedance.LungInflated,Tissue.Impedance.Bone);
Tissue.RefCoeff.HeartLungDeflated= ...
    ReflectionCoefficient(Tissue.Impedance.Heart,Tissue.Impedance.LungDeflated);
Tissue.RefCoeff.LungDeflatedBone= ...
    ReflectionCoefficient(Tissue.Impedance.LungDeflated,Tissue.Impedance.Bone);
Tissue.RefCoeff.BoneMuscle=...
    ReflectionCoefficient(Tissue.Impedance.Bone,Tissue.Impedance.Muscle);
Tissue.RefCoeff.MuscleFat=...
    ReflectionCoefficient(Tissue.Impedance.Muscle,Tissue.Impedance.Fat);
Tissue.RefCoeff.FatSkin=...
    ReflectionCoefficient(Tissue.Impedance.Fat,Tissue.Impedance.Skin);
Tissue.RefCoeff.SkinAir=...
    ReflectionCoefficient(Tissue.Impedance.Skin,Tissue.Impedance.FreeSpace);

% Propogation Constant (beta)

PermeabilityFreeSpace= 4*pi* 1e-7;  
w=2*pi*[5.4e9 7.3e9 8e9]; 

 Tissue.Beta.Skin =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Skin, Tissue.Conductivity.Skin); 
 Tissue.Beta.BreastFat =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.BreastFat, Tissue.Conductivity.BreastFat); 
 Tissue.Beta.Fat =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Fat, Tissue.Conductivity.Fat); 
 Tissue.Beta.Muscle =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace,...
    Tissue.ComplexPermittivity.Muscle, Tissue.Conductivity.Muscle); 
 Tissue.Beta.Cartilage =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace,...
    Tissue.ComplexPermittivity.Cartilage, Tissue.Conductivity.Cartilage); 
 Tissue.Beta.Heart =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Heart, Tissue.Conductivity.Heart); 
 Tissue.Beta.LungInflated =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.LungInflated, Tissue.Conductivity.LungInflated); 
 Tissue.Beta.LungDeflated =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace,...
    Tissue.ComplexPermittivity.LungDeflated, Tissue.Conductivity.LungDeflated); 
 Tissue.Beta.Bone =...
    PropogationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Bone, Tissue.Conductivity.Bone); 

% Attenuation Constant(alpha)

 Tissue.Alpha.Skin =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Skin, Tissue.Conductivity.Skin); 
 Tissue.Alpha.BreastFat =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.BreastFat, Tissue.Conductivity.BreastFat); 
 Tissue.Alpha.Fat =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Fat, Tissue.Conductivity.Fat); 
 Tissue.Alpha.Muscle =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace,...
    Tissue.ComplexPermittivity.Muscle, Tissue.Conductivity.Muscle); 
 Tissue.Alpha.Cartilage=...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace,...
    Tissue.ComplexPermittivity.Cartilage, Tissue.Conductivity.Cartilage); 
 Tissue.Alpha.Heart =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Heart, Tissue.Conductivity.Heart); 
 Tissue.Alpha.LungInflated =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.LungInflated, Tissue.Conductivity.LungInflated); 
 Tissue.Alpha.LungDeflated =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace,...
    Tissue.ComplexPermittivity.LungDeflated, Tissue.Conductivity.LungDeflated); 
 Tissue.Alpha.Bone =...
    AttenuationConstant(w, PermeabilityFreeSpace,Tissue.RealPermittivity.FreeSpace, ...
    Tissue.ComplexPermittivity.Bone, Tissue.Conductivity.Bone); 

% Skin Depth Calculation (delta) 

 Tissue.Delta.Skin = SkinDepthCalculation...
   (Tissue.Alpha.Skin);
 Tissue.Delta.BreastFat = SkinDepthCalculation...
   (Tissue.Alpha.BreastFat);
 Tissue.Delta.Fat = SkinDepthCalculation...
   (Tissue.Alpha.Fat);
 Tissue.Delta.Muscle = SkinDepthCalculation...
   (Tissue.Alpha.Muscle);
 Tissue.Delta.Cartilage = SkinDepthCalculation...
   (Tissue.Alpha.Cartilage);
 Tissue.Delta.Heart = SkinDepthCalculation...
   (Tissue.Alpha.Heart);
 Tissue.Delta.LungInflated = SkinDepthCalculation...
   (Tissue.Alpha.LungInflated);
 Tissue.Delta.LungDeflated = SkinDepthCalculation...
   (Tissue.Alpha.LungDeflated);
 Tissue.Delta.Bone = SkinDepthCalculation...
   (Tissue.Alpha.Bone);

 %%  STEP 4: Calculate reflected signals between neighbour tissues and total reflections %% 

%  The Reflected Signals(gamma) 

Tissue = InflatedLungParameters(Tissue); 
Tissue= DeflatedLungParameters(Tissue); 

% Tissue Adjoint Layering-Anterior-Posterior 

Tissue.LayeringOrder.DistanceLungInflated=...
    [Tissue.Distance.Skin1 Tissue.Distance.BreastFat Tissue.Distance.Muscle1...
    Tissue.Distance.Cartilage Tissue.Distance.Fat1 Tissue.Distance.Heart... 
    Tissue.Distance.LungInflated Tissue.Distance.Bone Tissue.Distance.Muscle2... 
    Tissue.Distance.Fat2 Tissue.Distance.Skin2]; 

Tissue.LayeringOrder.DistanceLungDeflated=...
    [Tissue.Distance.Skin1 Tissue.Distance.BreastFat Tissue.Distance.Muscle1...
    Tissue.Distance.Cartilage Tissue.Distance.Fat1 Tissue.Distance.Heart...
    Tissue.Distance.LungDeflated Tissue.Distance.Bone Tissue.Distance.Muscle2... 
    Tissue.Distance.Fat2 Tissue.Distance.Skin2]; 

 %%  STEP 5: Save the Tissue data %% 

 save(  strcat(TissueFilePath, "\TissueAnteriorPosterior",  ".mat"), "Tissue")




