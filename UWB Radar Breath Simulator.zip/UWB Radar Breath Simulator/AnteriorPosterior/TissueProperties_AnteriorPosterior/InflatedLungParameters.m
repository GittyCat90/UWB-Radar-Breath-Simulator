function [Tissue] = InflatedLungParameters(Tissue)

% InflatedLungParameters calculates the total reflection values for while
% lung is inflated. 

% INPUTS:
% Tissue.RefCoeff.[]=Reflection coefficients of the tissue layers between i, i+1. 
% Tissue.Beta.[]=Propogation constant. 
% Tissue.Distance= The width of the tissues, m. 

% Air-Skin Layering, 1-2

Tissue.Distance.Skin1=0.003; %m 

 [Tissue.ReflectedSignal.Skin1,Tissue.TransmittedSignal.Skin1] =...
 ReflectionTransmission(Tissue.RefCoeff.AirSkin,Tissue.RefCoeff.SkinBreastFat,...
 Tissue.Beta.Skin,Tissue.Distance.Skin1 );

Reflection2= Tissue.ReflectedSignal.Skin1; 
Transmission2= Tissue.TransmittedSignal.Skin1; 

% Skin-Breast Fat Layering, 2-3 
 
 Tissue.Distance.BreastFat=0.008; %m 

  [Tissue.ReflectedSignal.BreastFat,Tissue.TransmittedSignal.BreastFat] =...
 ReflectionTransmission(Tissue.RefCoeff.SkinBreastFat,Tissue.RefCoeff.BreastFatMuscle, ...
 Tissue.Beta.BreastFat,Tissue.Distance.BreastFat );

Reflection3=Tissue.ReflectedSignal.BreastFat; 
Transmission3=Tissue.TransmittedSignal.BreastFat; 

% Breast Fat-Muscle Layering, 3-4

 Tissue.Distance.Muscle1=0.01; %m 

  [Tissue.ReflectedSignal.Muscle1,Tissue.TransmittedSignal.Muscle1] =...
 ReflectionTransmission(Tissue.RefCoeff.BreastFatMuscle,Tissue.RefCoeff.MuscleCartilage,...
 Tissue.Beta.Muscle,Tissue.Distance.Muscle1 );

Reflection4=Tissue.ReflectedSignal.Muscle1;
Transmission4=Tissue.TransmittedSignal.Muscle1; 

% Muscle-Cartilage Layering, 4-5

 Tissue.Distance.Cartilage=0.006; %m 

  [Tissue.ReflectedSignal.Cartilage,Tissue.TransmittedSignal.Cartilage] =...
 ReflectionTransmission(Tissue.RefCoeff.MuscleCartilage,Tissue.RefCoeff.CartilageFat,...
 Tissue.Beta.Cartilage, Tissue.Distance.Cartilage );

Reflection5=Tissue.ReflectedSignal.Cartilage; 
Transmission5=Tissue.TransmittedSignal.Cartilage; 

% Cartilage-Fat Layering, 5-6

 Tissue.Distance.Fat1=0.005; %m 

  [Tissue.ReflectedSignal.Fat1,Tissue.TransmittedSignal.Fat1] =...
 ReflectionTransmission(Tissue.RefCoeff.CartilageFat,Tissue.RefCoeff.FatHeart, ...
 Tissue.Beta.Fat, Tissue.Distance.Fat1 );

Reflection6=Tissue.ReflectedSignal.Fat1; 
Transmission6=Tissue.TransmittedSignal.Fat1; 

% Fat-Heart Layering, 6-7

 Tissue.Distance.Heart=0.084; %m 

  [Tissue.ReflectedSignal.Heart,Tissue.TransmittedSignal.Heart] =...
 ReflectionTransmission(Tissue.RefCoeff.FatHeart,Tissue.RefCoeff.HeartLungInflated, ...
 Tissue.Beta.Heart, Tissue.Distance.Heart );

Reflection7=Tissue.ReflectedSignal.Heart; 
Transmission7=Tissue.TransmittedSignal.Heart; 

% Heart-Lung Inflated Layering, 7-8
Tissue.Distance.AnteroPosterior=0.031; 
 Tissue.Distance.LungInflated=0.07+Tissue.Distance.AnteroPosterior; %m 

  [Tissue.ReflectedSignal.LungInflated,Tissue.TransmittedSignal.LungInflated] =...
 ReflectionTransmission(Tissue.RefCoeff.HeartLungInflated, Tissue.RefCoeff.LungInflatedBone,...
 Tissue.Beta.LungInflated, Tissue.Distance.LungInflated );

Reflection8=Tissue.ReflectedSignal.LungInflated; 
Transmission8=Tissue.TransmittedSignal.LungInflated; 

% Lung Inflated-Bone Layering, 8-9

 Tissue.Distance.Bone=0.006; %m 

  [Tissue.ReflectedSignal.Bone, Tissue.TransmittedSignal.Bone] =...
 ReflectionTransmission(Tissue.RefCoeff.LungInflatedBone,Tissue.RefCoeff.BoneMuscle, ...
 Tissue.Beta.Bone,  Tissue.Distance.Bone );

Reflection9=Tissue.ReflectedSignal.Bone;
Transmission9=Tissue.TransmittedSignal.Bone; 

%Bone-Muscle Layering, 9-10

 Tissue.Distance.Muscle2=0.02; %m 

  [Tissue.ReflectedSignal.Muscle2, Tissue.TransmittedSignal.Muscle2] =...
 ReflectionTransmission(Tissue.RefCoeff.BoneMuscle, Tissue.RefCoeff.MuscleFat, ...
 Tissue.Beta.Muscle,  Tissue.Distance.Muscle2 );

Reflection10=Tissue.ReflectedSignal.Muscle2; 
Transmission10=Tissue.TransmittedSignal.Muscle2; 

%Muscle Fat Layering, 10-11

 Tissue.Distance.Fat2=0.002; %m 

  [Tissue.ReflectedSignal.Fat2, Tissue.TransmittedSignal.Fat2] =...
 ReflectionTransmission(Tissue.RefCoeff.MuscleFat, Tissue.RefCoeff.FatSkin,...
 Tissue.Beta.Fat,    Tissue.Distance.Fat2);

Reflection11= Tissue.ReflectedSignal.Fat2; 
Transmission11=Tissue.TransmittedSignal.Fat2; 

% Fat Skin Layering, 11-12

 Tissue.Distance.Skin2=0.003; %m 

  [Tissue.ReflectedSignal.Skin2, Tissue.TransmittedSignal.Skin2] =...
 ReflectionTransmission(Tissue.RefCoeff.FatSkin, Tissue.RefCoeff.SkinAir, ...
 Tissue.Beta.Skin,   Tissue.Distance.Skin2);

Reflection12=Tissue.ReflectedSignal.Skin2; 
Transmission12=Tissue.TransmittedSignal.Skin2; 

% Total Reflection and Transmission 

Tissue.TotalReflection.Inflated.R2=abs(Reflection2); 
Tissue.TotalReflection.Inflated.R3=abs((Transmission2.*Transmission2).*Reflection3); 
Tissue.TotalReflection.Inflated.R4=abs((Transmission2.*Transmission3).^2.*...
    Reflection4); 
Tissue.TotalReflection.Inflated.R5= abs((Transmission2.*Transmission3.*Transmission4).^2.*...
    Reflection5); 
Tissue.TotalReflection.Inflated.R6=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5).^2.*Reflection6); 
Tissue.TotalReflection.Inflated.R7=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6).^2.*Reflection7); 
Tissue.TotalReflection.Inflated.R8=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7).^2.*Reflection8); 
Tissue.TotalReflection.Inflated.R9=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8).^2.*Reflection9); 
Tissue.TotalReflection.Inflated.R10=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9).^2.*...
    Reflection10); 
Tissue.TotalReflection.Inflated.R11=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10).^2.*Reflection11); 
Tissue.TotalReflection.Inflated.R12=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11).^2.*Reflection12); 

% OUTPUTS
% Tissue.TotalReflection.Inflated.[]=Total reflection results, layer by layer. 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 




