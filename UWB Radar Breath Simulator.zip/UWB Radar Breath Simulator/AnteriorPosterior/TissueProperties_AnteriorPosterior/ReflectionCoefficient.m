function [RefCoeff12] = ReflectionCoefficient(CharImpedance1,CharImpedance2)

% ReflectionCoefficient calculates the reflection coefficients of two
% neighboring layers. 

% INPUTS 
% CharImpedance1: Characteristic impedance of the dielectric1, ohms. 
% CharImpedance2:  Characteristic impedance of the dielectric2, ohms. 

RefCoeff12=...
    ( CharImpedance1-CharImpedance2)./  ( CharImpedance1+CharImpedance2); 

% OUTPUTS 
% RefCoeff12: The reflection coefficient relative to the interface between dielectric k and
% k+1, (ro).

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 
