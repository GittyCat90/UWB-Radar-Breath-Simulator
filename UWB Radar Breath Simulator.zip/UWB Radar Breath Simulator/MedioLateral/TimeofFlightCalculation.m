function [TotalDelay] = ...
    TimeofFlightCalculation(RadarDistance,SpeedofLight,CenterFrequency, Tissue)

%TimeofFlightCalculation calculates the traveling time of radar pulses at
%each tissue layer from a spesified distance. 

% INPUTS 
% RadarDistance: The distance between the radar and human body, m. 
% SpeedofLight: The speed of electromagnetic wave in the vacuum, m/s. 
% CenterFrequency: The center frequency of the radar, Hz. 
% Tissue: Dataset that covers electromagnetic properties of the tissue. 

DelayAir=(2*RadarDistance)/SpeedofLight; %seconds 

% Lung Inflated 
TempInflated1=...
    ["Skin" "Fat" "Muscle" "Skin" "Air"  "Skin" "BreastFat" "Muscle" "Bone" "LungInflated"...
    "Fat" "Heart" "LungInflated" "Bone" "Muscle" "BreastFat" "Skin" "Air" "Skin" "Muscle"...
    "Fat" "Skin"]; 
TempInflated2=...
    ["Skin1"  "Fat1" "Muscle1" "Skin2"  "Air1" "Skin3" "BreastFat1" "Muscle2" "Bone1"...
    "LungInflated1" "Fat2" "Heart" "LungInflated2"  "Bone2" "Muscle3"  "BreastFat2" "Skin4"...
    "Air2" "Skin5" "Muscle4" "Fat3" "Skin6"]; 

% Lung Deflated 
TempDeflated1=...
    ["Skin" "Fat" "Muscle" "Skin" "Air"  "Skin" "BreastFat" "Muscle" "Bone" "LungDeflated"...
    "Fat" "Heart" "LungDeflated" "Bone" "Muscle" "BreastFat" "Skin" "Air" "Skin" "Muscle"...
    "Fat" "Skin"]; 
TempDeflated2=...
    ["Skin1"  "Fat1" "Muscle1" "Skin2"  "Air1" "Skin3" "BreastFat1" "Muscle2" "Bone1"...
    "LungDeflated1" "Fat2" "Heart" "LungDeflated2"  "Bone2" "Muscle3"  "BreastFat2" "Skin4"...
    "Air2" "Skin5" "Muscle4" "Fat3" "Skin6"]; 

ConstantVarNameVel= " Tissue.Velocity."; 
ConstantVarNameDistance="Tissue.Distance."; 

    for ii=1:length(TempInflated1) 
    
        for kk=1:length(CenterFrequency) 
                    % Lung Inflated
                    VarVel1=strcat( ConstantVarNameVel, TempInflated1(ii)); 
                    VarDistance1=strcat( ConstantVarNameDistance, TempInflated2(ii)); 
                    TissueDelayInflated(ii,:)= 2*eval(VarDistance1)./eval(VarVel1); 
                    TotalDelayInflated(ii,:) =DelayAir+TissueDelayInflated(ii,:); 
                    % Lung Deflated 
                     VarVel2=strcat( ConstantVarNameVel, TempDeflated1(ii)); 
                     VarDistance2=strcat( ConstantVarNameDistance, TempDeflated2(ii)); 
                     TissueDelayDeflated(ii,:)= 2*eval(VarDistance2)./eval(VarVel2); 
                     TotalDelayDeflated(ii,:) =DelayAir+TissueDelayDeflated(ii,:); 
            end 
    end 

% OUTPUTS 
% TotalDelayDeflated: The total time of flight  is  passed at specified distance considering each  
% human tissue layers, s.  The lung is deflated. 
% TotalDelayInflated:  The total time of flight  is  passed at specified distance considering each  
% human tissue layers, s.  The lung is inflated. 
% TissueDelayDeflated: The time of flight is passed at each tissue layers,
% s. The lung is deflated. 
% TissueDelayInflated: The time of flight is passed at each tissue layers,
% s. The lung is inflated. 
% DelayAir: The total time of flight is passed at specified distance, without considering
% tissue widths,  m. 

TotalDelay.Deflated=TotalDelayDeflated; 
TotalDelay.Inflated=TotalDelayInflated; 
TotalDelay.TissueDelay.Deflated=TissueDelayDeflated; 
TotalDelay.TissueDelay.Inflated=TissueDelayInflated; 
TotalDelay.DelayAir=DelayAir; 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 

