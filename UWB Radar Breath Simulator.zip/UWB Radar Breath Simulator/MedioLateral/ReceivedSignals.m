function [ReceivedBreath] =...
    ReceivedSignals(PeriodNumber, Coefficient,MaskdB,Pulsewidth, tlocal)

%ReceivedSignals calculates the collected echo signals. 

%We assumed that radar collects maximum 100 echo samples at each cycle
%during breathing that corresponds to 5 seconds where the period is 10. 
% We consider the first three layers of the tissues due to their robust
% reflection coefficient compared to other remaining tissue layers. 

% INPUTS 
% PeriodNumber: The number of periods for an observation time. 
% Coefficient: The Reflection coefficients and the path losses(dB) that
% consider the movement of the lungs while breathing. 
% MaskdB: The power of input signal, dB. 
% Pulsewidth: The pulsewidth of the Gauss pulse, seconds. 
% tlocal: Time vector for a Gauss pulse, seconds. 

LossCell=Coefficient.LossCell;
GammaCell=Coefficient.GammaCell; 
SampleNumbers=Coefficient.SampleNumbers; 
NumberofCenterFrequency=3; 
NumberofTissueLayer=11; 
AmplitudeReceiverGain=250; 
AntennaGain=10; %dBi 


Store=[]; 

      for aa=1:PeriodNumber

                Loss=LossCell{aa}; 
                Gamma=GammaCell{aa};
        
                        for kk=1:NumberofCenterFrequency
        
                                for  ii=1:NumberofTissueLayer
        
                                        for jj=1:SampleNumbers(aa)  
        
                                                 ReceiverGain=10*log10(AmplitudeReceiverGain)+AntennaGain;       
                                                 MaskdBLossy=ReceiverGain+MaskdB-Loss(kk,ii,jj);
                                                 GaussPulse = GaussPulseGenerator(Pulsewidth,MaskdBLossy, tlocal); 
                                                 GaussPulse=fft(Gamma(kk,ii,jj)).*fft(GaussPulse);
                                                 GaussPulse=ifft(GaussPulse);

                                                                 for bb=1:length(GaussPulse)
                                                                     if GaussPulse(bb)==max(GaussPulse)
                                                                         GaussPulse(bb)=max(GaussPulse); 
                                                                     else 
                                                                         GaussPulse(bb)=0; 
                                                                     end 
                                                                 end 
                                                                 
                                                 Store=[Store GaussPulse]; 
        
                                        end 
        
                                 Received(kk,ii,:)=abs(envelope(  Store, 30,'peak')); 
                                 Store=[]; 
        
                               end 
        
                        end 

            ReceivedCell{aa}=Received; 
            Received=[]; 

    end
    
% Extract the breath signals in observation time.  
   
            Breath=[];

            for kk=1:NumberofCenterFrequency
                for ii=1:NumberofTissueLayer
                    for aa=1:PeriodNumber
                            Temp1=ReceivedCell{aa};
                            Temp2=squeeze(Temp1(kk,ii,:)); 
                            Temp2=Temp2';
                            Breath=[Breath Temp2]; 
                    end 
                    ReceivedBreath(kk,ii,:)=Breath; 
                    Breath=[]; 
                end 
            end 
            
   % OUTPUTS 
   % ReceivedBreath: The collected breath signals. 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 
