function [ReflectedSignal2,TransmittedSignal2] = ...
    ReflectionTransmission(TissueRefCoeff12,TissueRefCoeff23, TissueBeta,TissueDistance )

% ReflectionTransmission calculates the total reflected and transmitted
% signals regarding neigbouring layers. 

% INPUTS
%TissueRefCoeff12: Reflection coefficient between i-1, i layer, example. 1-2
%TissueRefCoeff23: Reflection coefficient between i, i+1 layer, example. 2-3
%TissueDistance: The width of the each layer, m. 
%TissueBeta: Propogation constant of each layer. 

ReflectedSignal2= ...
    TissueRefCoeff12+ TissueRefCoeff23.*exp( -2.*TissueBeta* TissueDistance)./ ...
    ( 1+ TissueRefCoeff12.* TissueRefCoeff23.*exp( -2.*TissueBeta.* TissueDistance)); 

TransmittedSignal2= ...
    (1+TissueRefCoeff12).*(1+ TissueRefCoeff23).*exp( -2.*TissueBeta* TissueDistance)./ ...
    ( 1+ TissueRefCoeff12.* TissueRefCoeff23.*exp( -2.*TissueBeta* TissueDistance)); 

% OUTPUTS 
%ReflectedSignal2: The reflection coefficient, i, (gamma). 
%TransmittedSignal2: The transmission coefficient, i. 
 
end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 
