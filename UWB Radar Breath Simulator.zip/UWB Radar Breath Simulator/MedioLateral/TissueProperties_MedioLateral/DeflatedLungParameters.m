function [Tissue] = DeflatedLungParameters(Tissue)

% DeflatedLungParameters calculates the total reflection values for while
% lung is deflated. 

% INPUTS:
% Tissue.RefCoeff.[]=Reflection coefficients of the tissue layers between i, i+1. 
% Tissue.Beta.[]=Propogation constant. 
% Tissue.Distance= The width of the tissues, m. 

% Air-Skin Layering, 1-2

Tissue.Distance.Skin1=0.003; %m 

 [Tissue.ReflectedSignal.Skin1,Tissue.TransmittedSignal.Skin1] =...
 ReflectionTransmission(Tissue.RefCoeff.AirSkin,Tissue.RefCoeff.SkinFat, ...
 Tissue.Beta.Skin,Tissue.Distance.Skin1 );

Reflection2= Tissue.ReflectedSignal.Skin1; 
Transmission2= Tissue.TransmittedSignal.Skin1; 

% Skin-Fat Layering, 2-3

Tissue.Distance.Fat1=0.008; %m 

 [Tissue.ReflectedSignal.Fat1,Tissue.TransmittedSignal.Fat1] =...
 ReflectionTransmission(Tissue.RefCoeff.SkinFat, Tissue.RefCoeff.FatMuscle, ...
 Tissue.Beta.Fat,Tissue.Distance.Fat1 );

Reflection3= Tissue.ReflectedSignal.Fat1; 
Transmission3= Tissue.TransmittedSignal.Fat1; 

% Fat-Muscle Layering, 3-4

Tissue.Distance.Muscle1=0.031;  %m 

 [Tissue.ReflectedSignal.Muscle1,Tissue.TransmittedSignal.Muscle1] =...
 ReflectionTransmission(Tissue.RefCoeff.FatMuscle, Tissue.RefCoeff.MuscleSkin, ...
 Tissue.Beta.Muscle,Tissue.Distance.Muscle1 );

Reflection4= Tissue.ReflectedSignal.Muscle1; 
Transmission4= Tissue.TransmittedSignal.Muscle1; 

% Muscle-Skin Layering, 4-5

Tissue.Distance.Skin2=0.003;  %m 

 [Tissue.ReflectedSignal.Skin2,Tissue.TransmittedSignal.Skin2] =...
 ReflectionTransmission(Tissue.RefCoeff.MuscleSkin, Tissue.RefCoeff.SkinAir,...
 Tissue.Beta.Skin,Tissue.Distance.Skin2 );

Reflection5= Tissue.ReflectedSignal.Skin2; 
Transmission5= Tissue.TransmittedSignal.Skin2; 

%  Skin-Air Layering, 5-6

Tissue.Distance.Air1=0.018;  %m 

 [Tissue.ReflectedSignal.Air1,Tissue.TransmittedSignal.Air1] =...
 ReflectionTransmission(Tissue.RefCoeff.SkinAir, Tissue.RefCoeff.AirSkin, ...
 Tissue.Beta.Air,Tissue.Distance.Air1 );

Reflection6= Tissue.ReflectedSignal.Air1; 
Transmission6= Tissue.TransmittedSignal.Air1; 

%  Air-Skin Layering, 6-7

Tissue.Distance.Skin3=0.003;  %m 

 [Tissue.ReflectedSignal.Skin3,Tissue.TransmittedSignal.Skin3] =...
 ReflectionTransmission(Tissue.RefCoeff.AirSkin, Tissue.RefCoeff.SkinBreastFat,...
 Tissue.Beta.Skin,Tissue.Distance.Skin3 );

Reflection7= Tissue.ReflectedSignal.Skin3; 
Transmission7= Tissue.TransmittedSignal.Skin3; 

%  Skin-BreastFat Layering, 7-8

Tissue.Distance.BreastFat1=0.008;  %m 

 [Tissue.ReflectedSignal.BreastFat1,Tissue.TransmittedSignal.BreastFat1] =...
 ReflectionTransmission(Tissue.RefCoeff.SkinBreastFat, Tissue.RefCoeff.BreastFatMuscle, ...
 Tissue.Beta.BreastFat,Tissue.Distance.BreastFat1 );

Reflection8= Tissue.ReflectedSignal.BreastFat1; 
Transmission8= Tissue.TransmittedSignal.BreastFat1; 

%  BreastFat-Muscle Layering, 8-9

Tissue.Distance.Muscle2=0.014;  %m 

 [Tissue.ReflectedSignal.Muscle2,Tissue.TransmittedSignal.Muscle2] =...
 ReflectionTransmission(Tissue.RefCoeff.BreastFatMuscle, Tissue.RefCoeff.MuscleBone, ...
 Tissue.Beta.Muscle,Tissue.Distance.Muscle2 );

Reflection9= Tissue.ReflectedSignal.Muscle2; 
Transmission9= Tissue.TransmittedSignal.Muscle2; 

%Muscle-Bone Layering, 9-10

Tissue.Distance.Bone1=0.005;  %m 

 [Tissue.ReflectedSignal.Bone1,Tissue.TransmittedSignal.Bone1] =...
 ReflectionTransmission(Tissue.RefCoeff.MuscleBone, Tissue.RefCoeff.BoneLungDeflated, ...
 Tissue.Beta.Bone,Tissue.Distance.Bone1 );

Reflection10= Tissue.ReflectedSignal.Bone1; 
Transmission10= Tissue.TransmittedSignal.Bone1; 

%Bone-LungDeflated Layering, 10-11

Tissue.Distance.LungDeflated1=0.062;  %m 

 [Tissue.ReflectedSignal.LungDeflated1,Tissue.TransmittedSignal.LungDeflated1] =...
 ReflectionTransmission(Tissue.RefCoeff.BoneLungDeflated, Tissue.RefCoeff.LungDeflatedFat,...
 Tissue.Beta.LungDeflated,Tissue.Distance.LungDeflated1 );

Reflection11= Tissue.ReflectedSignal.LungDeflated1; 
Transmission11= Tissue.TransmittedSignal.LungDeflated1; 

%LungDeflated- Fat Layering, 11-12

Tissue.Distance.Fat2=0.012;  %m 

 [Tissue.ReflectedSignal.Fat2,Tissue.TransmittedSignal.Fat2] =...
 ReflectionTransmission(Tissue.RefCoeff.LungDeflatedFat, Tissue.RefCoeff.FatHeart,...
 Tissue.Beta.Fat,Tissue.Distance.Fat2 );

Reflection12= Tissue.ReflectedSignal.Fat2; 
Transmission12= Tissue.TransmittedSignal.Fat2; 

%Fat-Heart Layering, 12-13

Tissue.Distance.Heart=0.106;  %m 

 [Tissue.ReflectedSignal.Heart,Tissue.TransmittedSignal.Heart] =...
 ReflectionTransmission(Tissue.RefCoeff.FatHeart, Tissue.RefCoeff.HeartLungDeflated,...
 Tissue.Beta.Heart,Tissue.Distance.Heart );

Reflection13= Tissue.ReflectedSignal.Heart; 
Transmission13= Tissue.TransmittedSignal.Heart; 

%Heart-LungDeflated Layering, 13-14

Tissue.Distance.LungDeflated2=0.036;  %m 

 [Tissue.ReflectedSignal.LungDeflated2,Tissue.TransmittedSignal.LungDeflated2] =...
 ReflectionTransmission(Tissue.RefCoeff.HeartLungDeflated, Tissue.RefCoeff.LungDeflatedBone,...
 Tissue.Beta.LungDeflated,Tissue.Distance.LungDeflated2 );

Reflection14= Tissue.ReflectedSignal.LungDeflated2; 
Transmission14= Tissue.TransmittedSignal.LungDeflated2; 

%LungDeflated-Bone Layering, 14-15

Tissue.Distance.Bone2=0.005;  %m 

 [Tissue.ReflectedSignal.Bone2,Tissue.TransmittedSignal.Bone2] =...
 ReflectionTransmission(Tissue.RefCoeff.LungDeflatedBone, Tissue.RefCoeff.BoneMuscle,...
 Tissue.Beta.Bone,Tissue.Distance.Bone2 );

Reflection15= Tissue.ReflectedSignal.Bone2; 
Transmission15= Tissue.TransmittedSignal.Bone2; 

%Bone-Muscle Layering, 15-16

Tissue.Distance.Muscle3=0.006;  %m 

 [Tissue.ReflectedSignal.Muscle3,Tissue.TransmittedSignal.Muscle3] =...
 ReflectionTransmission(Tissue.RefCoeff.BoneMuscle, Tissue.RefCoeff.MuscleBreastFat,...
 Tissue.Beta.Muscle,Tissue.Distance.Muscle3 );

Reflection16= Tissue.ReflectedSignal.Muscle3; 
Transmission16= Tissue.TransmittedSignal.Muscle3; 

%Muscle-Breast Fat  Layering, 16-17

Tissue.Distance.BreastFat2=0.004;  %m 

 [Tissue.ReflectedSignal.BreastFat2,Tissue.TransmittedSignal.BreastFat2] =...
 ReflectionTransmission(Tissue.RefCoeff.MuscleBreastFat, Tissue.RefCoeff.BreastFatSkin,...
 Tissue.Beta.BreastFat,Tissue.Distance.BreastFat2 );

Reflection17= Tissue.ReflectedSignal.BreastFat2; 
Transmission17= Tissue.TransmittedSignal.BreastFat2; 

%Breast Fat-Skin Layering, 17-18

Tissue.Distance.Skin4=0.003;  %m 

 [Tissue.ReflectedSignal.Skin4,Tissue.TransmittedSignal.Skin4] =...
 ReflectionTransmission(Tissue.RefCoeff.BreastFatSkin, Tissue.RefCoeff.SkinAir,...
 Tissue.Beta.Skin,Tissue.Distance.Skin4 );

Reflection18= Tissue.ReflectedSignal.Skin4; 
Transmission18= Tissue.TransmittedSignal.Skin4; 

%Skin-Air Layering, 18-19

Tissue.Distance.Air2=0.018;  %m 

 [Tissue.ReflectedSignal.Air2,Tissue.TransmittedSignal.Air2] =...
 ReflectionTransmission(Tissue.RefCoeff.SkinAir, Tissue.RefCoeff.AirSkin,...
 Tissue.Beta.Air,Tissue.Distance.Air2 );

Reflection19= Tissue.ReflectedSignal.Air2; 
Transmission19= Tissue.TransmittedSignal.Air2; 

%Air-Skin Layering, 19-20

Tissue.Distance.Skin5=0.003;  %m 

 [Tissue.ReflectedSignal.Skin5,Tissue.TransmittedSignal.Skin5] =...
 ReflectionTransmission(Tissue.RefCoeff.AirSkin, Tissue.RefCoeff.SkinMuscle,...
 Tissue.Beta.Skin,Tissue.Distance.Skin5 );

Reflection20= Tissue.ReflectedSignal.Skin5; 
Transmission20= Tissue.TransmittedSignal.Skin5; 

%Skin-Muscle Layering, 20-21

Tissue.Distance.Muscle4=0.038;  %m 

 [Tissue.ReflectedSignal.Muscle4,Tissue.TransmittedSignal.Muscle4] =...
 ReflectionTransmission(Tissue.RefCoeff.SkinMuscle, Tissue.RefCoeff.MuscleFat,...
 Tissue.Beta.Muscle,Tissue.Distance.Muscle4 );

Reflection21= Tissue.ReflectedSignal.Muscle4; 
Transmission21= Tissue.TransmittedSignal.Muscle4; 

%Muscle-Fat Layering, 21-22

Tissue.Distance.Fat3=0.010;  %m 

 [Tissue.ReflectedSignal.Fat3,Tissue.TransmittedSignal.Fat3] =...
 ReflectionTransmission(Tissue.RefCoeff.MuscleFat, Tissue.RefCoeff.FatSkin,...
 Tissue.Beta.Fat,Tissue.Distance.Fat3 );

Reflection22= Tissue.ReflectedSignal.Fat3; 
Transmission22= Tissue.TransmittedSignal.Fat3; 

%Fat-Skin Layering, 22-23

Tissue.Distance.Skin6=0.003;  %m 

 [Tissue.ReflectedSignal.Skin6,Tissue.TransmittedSignal.Skin6] =...
 ReflectionTransmission(Tissue.RefCoeff.FatSkin, Tissue.RefCoeff.SkinAir,...
 Tissue.Beta.Skin,Tissue.Distance.Skin6 );

Reflection23= Tissue.ReflectedSignal.Skin6; 
Transmission23= Tissue.TransmittedSignal.Skin6; 

% Total Reflection and Transmission 

Tissue.TotalReflection.Deflated.R2=abs(Reflection2); 
Tissue.TotalReflection.Deflated.R3=abs((Transmission2.*Transmission2).*Reflection3); 
Tissue.TotalReflection.Deflated.R4=...
    abs((Transmission2.*Transmission3).^2.*Reflection4); 
Tissue.TotalReflection.Deflated.R5=...
    abs((Transmission2.*Transmission3.*Transmission4).^2.*Reflection5); 
Tissue.TotalReflection.Deflated.R6=...
    abs((Transmission2.*Transmission3.*Transmission4.*Transmission5).^2.*Reflection6); 
Tissue.TotalReflection.Deflated.R7=...
    abs((Transmission2.*Transmission3.*Transmission4.*Transmission5.*Transmission6).^2.*...
    Reflection7); 
Tissue.TotalReflection.Deflated.R8=...
    abs((Transmission2.*Transmission3.*Transmission4.*Transmission5.*Transmission6.*...
    Transmission7).^2.*Reflection8); 
Tissue.TotalReflection.Deflated.R9=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8).^2.*Reflection9); 
Tissue.TotalReflection.Deflated.R10=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9).^2.*...
    Reflection10); 
Tissue.TotalReflection.Deflated.R11=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10).^2.*Reflection11); 
Tissue.TotalReflection.Deflated.R12=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11).^2.*Reflection12); 
Tissue.TotalReflection.Deflated.R13=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12).^2.*Reflection13); 
Tissue.TotalReflection.Deflated.R14=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13).^2.*Reflection14); 
Tissue.TotalReflection.Deflated.R15=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14).^2.*...
    Reflection15); 
Tissue.TotalReflection.Deflated.R16=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15).^2.*Reflection16); 
Tissue.TotalReflection.Deflated.R17=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15.*Transmission16).^2.*Reflection17); 
Tissue.TotalReflection.Deflated.R18=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15.*Transmission16.*Transmission17).^2.*Reflection18); 
Tissue.TotalReflection.Deflated.R19=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15.*Transmission16.*Transmission17.*Transmission18).^2.*Reflection19); 
Tissue.TotalReflection.Deflated.R20=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15.*Transmission16.*Transmission17.*Transmission18.*Transmission19).^2.*...
    Reflection20); 
Tissue.TotalReflection.Deflated.R21=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15.*Transmission16.*Transmission17.*Transmission18.*Transmission19.*...
    Transmission20).^2.*Reflection21); 
Tissue.TotalReflection.Deflated.R22=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15.*Transmission16.*Transmission17.*Transmission18.*Transmission19.*...
    Transmission20.*Transmission21).^2.*Reflection22); 
Tissue.TotalReflection.Deflated.R23=abs((Transmission2.*Transmission3.*Transmission4.*...
    Transmission5.*Transmission6.*Transmission7.*Transmission8.*Transmission9.*...
    Transmission10.*Transmission11.*Transmission12.*Transmission13.*Transmission14.*...
    Transmission15.*Transmission16.*Transmission17.*Transmission18.*Transmission19.*...
    Transmission20.*Transmission21.*Transmission22).^2.*Reflection23); 

% OUTPUTS
% Tissue.TotalReflection.Deflated.[]=Total reflection results, layer by layer. 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 

