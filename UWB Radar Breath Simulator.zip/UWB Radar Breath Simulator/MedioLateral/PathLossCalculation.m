function [PathLoss] = ...
    PathLossCalculation...
    (CenterFrequency, RadarDistance, Tissue)

%PathLossCalculation of this function is given below.

% INPUTS 
% CenterFrequency: The radar center frequencies, Hz. 
% RadarDistance: The nominal distance between radar and human, m. 
% Tissue: Dataset that covers EM properties of the tissue. 

ThoraxLayerOrder1=Tissue.LayeringOrder.DistanceLungInflated; 
ThoraxLayerOrder2=Tissue.LayeringOrder.DistanceLungDeflated; 
LungDistance=Tissue.Distance.MedioLateral;  

CenterFrequency=CenterFrequency./1e6; % Hz to MHz conversion 

% Generate distance sum adder. 

StoreThroaxSumInflated=zeros(1, length(ThoraxLayerOrder1)); 
ThroaxSumInflated=0;
StoreThroaxSumDeflated=zeros(1, length(ThoraxLayerOrder2)); 
ThroaxSumDeflated=0;

for  ii=1:length(ThoraxLayerOrder1)
        ThroaxSumInflated=ThroaxSumInflated+ThoraxLayerOrder1(ii) ;
        StoreThroaxSumInflated(ii)=ThroaxSumInflated; 
        ThroaxSumDeflated=ThroaxSumDeflated+ThoraxLayerOrder2(ii) ;
        StoreThroaxSumDeflated(ii)=ThroaxSumDeflated;        
end 

% Loss Calculation 

for kk=1:length(CenterFrequency)
    
    for ii=1:length(ThoraxLayerOrder1)
        
        PathLoss.LungInflated(kk,ii)=-...
            27.55+40*log10(RadarDistance-LungDistance+...
            StoreThroaxSumInflated(ii))+20*log10(CenterFrequency(kk)); 
        PathLoss.LungDeflated(kk,ii)=-27.55+40*log10(RadarDistance+StoreThroaxSumDeflated(ii))+...
            20*log10(CenterFrequency(kk));             
    
    end 
 
end 

% OUTPUTS 
% PathLoss: The calculated free space path loss values, dB. 

end

%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 

