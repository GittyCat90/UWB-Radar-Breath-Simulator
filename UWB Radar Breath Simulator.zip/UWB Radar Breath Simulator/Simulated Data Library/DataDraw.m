
clc
clear all
close all
 
%% This code is written in MATLAB R2020a. 
%% Author: Cansu EREN 
%% Copyright (C) 2023 Cansu EREN 

%% This program is free software: you can redistribute it and/or modify it under the terms...
%% of the GNU General Public License as published by the Free Software Foundation,  
%% version 3 of the License. Further information, please check GNU General Public License 
%% v3.0 .txt. 

%% This data is used under the terms of  ODC Open Database License (ODbL). Further 
%% information, please check GNU General Public License(ODbL).txt 

QuestionStruct.Interpreter='tex'; 
QuestionStruct.Default='Yes'; 
Question=...
    questdlg('\fontsize{14}\color{magenta}Select "RespirationModel" file location', 'Question', 'Yes', 'No', 'Cancel', QuestionStruct); 

switch Question 
    case 'Yes'
      FilePath=uigetdir; 
    case 'No'
        MessageStruct.Interpreter='tex'; 
        MessageStruct.WindowsStyle='modal'; 
        Message=msgbox({'\fontsize{14}\color{magenta}You should select "RespirationModel" file location'}, 'ReadMe', 'help', MessageStruct); 
        clc 
        clear all 
        close all 
       return 
    case 'Cancel'
        clc 
        clear all 
        close all 
        return 
end 

TimeDur=50; %seconds 
SimulatedFilePath=fullfile(FilePath, "Simulated Data Library"); 
[DataName,PathName]=uigetfile; 
load(strcat(DataName)); 

if contains( DataName, "Path")
        MessageStruct.Interpreter='tex'; 
        MessageStruct.WindowsStyle='modal'; 
        Message= msgbox("You can observe Pathloss in workspace","Check Workspace","warn");

else contains( DataName, "Received")

        L=length(squeeze(ReceivedBreath(1,1,:))); 
        tt=0:TimeDur/L:TimeDur-TimeDur/L; 
        Fs=1/(TimeDur/L); 
        ffres=Fs/L;
        ff=0:ffres: Fs-ffres; 
        Spectrum=abs(fft(squeeze(ReceivedBreath(1,1,:)))); 
        Spectrum=Spectrum(4:250); 
        figure 
        subplot(121)
         plot(tt, squeeze(ReceivedBreath(1,1,:)))
         xlabel("Time (seconds)", "FontSize",16,"FontWeight", "bold")
         ylabel("Amplitude ", "FontSize",16, "FontWeight", "bold")
         title(strcat( "First Layer, ", DataName))
        subplot(122)
         plot(ff(4:250), Spectrum)
         xlabel("Frequency (Hz)", "FontSize",16,"FontWeight", "bold")
         ylabel("Magnitude ", "FontSize",16, "FontWeight", "bold")
         title(strcat( "First Layer, ", DataName))

end 